#include <RcppArmadillo.h>
#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;

double MAD(arma::vec r)
{
  vec temp = r-median(r)*ones<vec>(r.n_elem);
  double MAD = median(abs(temp));
  return MAD;
}

arma::mat change(arma::mat &x)
{
  int n = x.n_rows;
  mat Xnew = x;
  Xnew.insert_cols(0, ones<vec>(n));
  return Xnew;
}

//' Compute the maximum likelihood type estimates.
//' 
//' @param y the sample vector of the dependent variable
//' @param x the sample matrix of the independent variables
//' @return the estimated regression coefficients
// [[Rcpp::export]]
arma::vec M_IRLS(arma::vec y, arma::mat x)
{
  x = change(x);
  vec beta0 = solve(x.t()*x,x.t()*y);
  vec beta1;
  for(int k=0;k<200;k++)
  {
    vec r = y-x*beta0;
    double sigma = MAD(r)/0.6745;
    if(sigma==0)
    {
      beta1 = beta0;
      break;
    }
    r = r/sigma;
    vec w = r.transform([](double u) 
    {return (abs(u)<=1.345)?1:(1.345/abs(u));});
    beta1 = solve(x.t()*diagmat(w)*x,x.t()*(w%y));
    vec err = abs(beta1-beta0)/abs(beta0);
    if(all(err < 1e-5))
      break;
    beta0 = beta1;
  }
  return beta1;
}

//' Compute the least trimmed squares.
//' 
//' @param y the sample vector of the dependent variable
//' @param x the sample matrix of the independent variables
//' @param rate the proportion of truncated data to original data
//' @return the estimated regression coefficients
// [[Rcpp::export]]
arma::vec LTSreg(arma::vec y, arma::mat x, double rate=0.85)
{
  x = change(x);
  int n = y.n_elem, p = x.n_cols;
  int h = ceil(rate*n), N = 1 + n/(p+1);
  uvec q = regspace<uvec>(0, n - 1);
  mat beta_set(p,N);
  vec r_set(N);
  
  for(int i=0;i<N;i++)
  {
    uvec subIndex = Rcpp::RcppArmadillo::sample(q,p+1,false);
    mat XSub = x.rows(subIndex);
    vec ySub = y.rows(subIndex);
    beta_set.col(i) = solve(XSub.t() * XSub, XSub.t() * ySub);
    vec rid = sort(abs(y-x*beta_set.col(i)));
    
    rid = rid.head(h);
    r_set(i) = sum(rid % rid);
  }
  
  uvec ind = find(r_set == min(r_set));
  vec betaHat = beta_set.col(ind(0));
  return betaHat;
}

//' Compute the median-based linear models, which contains Theil-Sen single median regression and Siegel repeated medians regression.
//' 
//' @param x the vector x-coordinate of the sample points
//' @param y the vector y-coordinate of the sample points
//' @param repeated the bool that repeated = TRUE means Siegel regression and repeated = FALSE means Theil-Sen regression
//' @return the estimated regression slope and intercept
// [[Rcpp::export]]
Rcpp::List median_lm(arma::vec x, arma::vec y,bool repeated)
{
  int n=x.n_elem;
  double slope,intercept;
  vec smedians, imedians;
  vec slopes, intercepts;
  if (repeated){
    for(int i=0;i<n;i++){
      vec slopes, intercepts;
      for(int j=0;j<n;j++){
        if(x(i)!=x(j)){
          slopes.resize(slopes.n_elem +1);
          slopes(slopes.n_elem-1)=(y(j) - y(i))/(x(j) - x(i));
          intercepts.resize(intercepts.n_elem +1);
          intercepts(intercepts.n_elem-1)=(x(j) * y(i) - x(i) * y(j))/(x(j) - x(i));
        }
      }
      smedians.resize(smedians.n_elem +1);
      smedians(smedians.n_elem-1)=median(slopes);
      imedians.resize(imedians.n_elem +1);
      imedians(imedians.n_elem-1)=median(intercepts);
    }
    slope = median(smedians);
    intercept = median(imedians);
  }
  else{
    for(int i=0;i<n-1;i++){
      for(int j=i;j<n;j++){
        if(x(i)!=x(j)){
          slopes.resize(slopes.n_elem +1);
          slopes(slopes.n_elem-1)=(y(j) - y(i))/(x(j) - x(i));
        }
      }
    }
    slope=median(slopes);
    intercepts = y - slope * x;
    intercept = median(intercepts);
  }
  return Rcpp::List::create(Rcpp::Named("slope") = slope,
                            Rcpp::Named("intercept") = intercept);
}


//' Compute the ordinary least squares.
//' 
//' @param x the observed matrix
//' @param y the observed vector
//' @return the estimated regression coefficients
// [[Rcpp::export]]
arma::vec OLS(arma::mat x, arma::vec y){
  arma::vec betaHat(x.n_cols);
  arma::mat x0(x.n_rows, 1, fill::ones );
  x.insert_cols(0,x0);
  
  betaHat = solve( x.t()*x, x.t()*y );
  return betaHat;
}


//' Compute RANSAC
//' 
//' @param x the observed matrix
//' @param y the observed vector
//' @param k the max iteration step-size 
//' @param t acceptable difference between data and model
//' @return the estimated regression coefficients
// [[Rcpp::export]]
arma::vec RANSAC(arma::mat x, arma::vec y,int k,double t){
  
  arma::mat x0(x.n_rows, 1, fill::ones );
  x.insert_cols(0,x0);
  int n = x.n_rows;
  int m = x.n_cols;
  vec v = regspace(0,n-1);
  vec u;
  vec w;
  mat X(m,m);
  vec Y(m);
  vec Bethat(m);
  vec BestBethat(m);
  int bestCore=0;
  int countCore;
  double Residual;
  for (int i=1;i<=k;i++){
    countCore = 0;
    // choose random points
    u = Rcpp::RcppArmadillo::sample(v,m,false);
    for (int j=0;j<m;j++){
      X.row(j) = x.row(u(j));
      Y(j) = y(u(j));
      
    }
    Bethat = solve( X.t()*X, X.t()*Y );
    for (int j=0;j<n;j++){
      Residual = abs(dot(x.row(j),Bethat)-y(j));
      if (Residual<t){
        countCore += 1;
      }
      
    }
    if (countCore>bestCore){
      bestCore = countCore;
      BestBethat = Bethat;
    }
    
  }
  return BestBethat;
  
}
